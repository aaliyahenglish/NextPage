//
//  NextpageAppTests.swift
//  NextpageAppTests
//
//  Created by Aaliyah English on 11/28/25.
//

import Testing
@testable import NextpageApp

struct NextpageAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
